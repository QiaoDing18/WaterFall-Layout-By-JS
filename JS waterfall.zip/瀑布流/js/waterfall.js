window.onload = function(){
	//封装函数，传入class
	waterFall("main", "box");
	//加载的思路：定义两个高度，一个是要加载的条件高度，另一个是已滑动的高度
	//模拟jason数据
	var dataInt = {"data" : [{"src": '1.jpg'}, {"src": '2.jpg'}, {"src": '3.jpg'}, {"src": '4.jpg'}, {"src": '5.jpg'}, ]};
	window.onscroll = function(){
		//为真就满足了数据块加载的条件
		if(checkScrollSlide()){
			var oParent = document.getElementById("main");
			//将数据块渲染到页面尾部
			//遍历数据，知道有多少
			for(var i=0; i<dataInt.data.length; i++){
				var oBox = document.createElement("div");
				oBox.className = "box";
				oParent.appendChild(oBox);
				var oContent = document.createElement("div");
				oContent.className = "content";
				oBox.appendChild(oContent);
				var oImg = document.createElement("img");
				//指定img的src
				oImg.src = "img/" + dataInt.data[i].src;
				oContent.appendChild(oImg);
			}
			//调用排版函数，保证新加入的不乱
			waterFall("main", "box");
		}
	};
};
//封装函数，传入的参数对应classname
function waterFall(parent, box){
	//将main下所有元素为img-box的元素取下来
	var oParent = document.getElementById(parent);
	//封装一个模拟取class的函数
	var oBoxs = getByClass(oParent, box);
	//整个页面的列数。页面宽除以box宽
	var oBoxW = oBoxs[0].offsetWidth;
	//列数
	var cols = Math.floor(document.documentElement.clientWidth/oBoxW);
	//设置main宽，居中
	oParent.style.cssText = 'width:'+oBoxW*cols+'px;margin:0 auto';
	//定义存每一列高度的数组
	var hArr = [];
	for(var i=0; i<oBoxs.length; i++){
		if(i<cols){
//			console.log(cols);
			hArr.push(oBoxs[i].offsetHeight);
		} else {
			//定义变量存最小的
			var minH = Math.min.apply(null, hArr);
			//保存最小的那一列
			var index = getMinhIndex(hArr, minH);
			//添加样式
			oBoxs[i].style.position = "absolute";
			oBoxs[i].style.top = minH + "px";
			oBoxs[i].style.left = oBoxW*index + "px";
			//保证不重复
			hArr[index] += oBoxs[i].offsetHeight;
		}
	}
}

//封装一个模拟取class的函数
function getByClass(parent, clsName){
	//通过传来的父元素，依次遍历判断是否为class
	var boxArr = [];	//用它存class为box的元素
	var oElements = parent.getElementsByTagName('*');	//获取父元素下所有元素
	for(var i=0; i<oElements.length; i++){
		if(oElements[i].className == clsName){
			boxArr.push(oElements[i]);
			//如果传来的相等，就放进classBox中
		}
	}
	return boxArr;
}
//得到最小高度的函数
function getMinhIndex(arr, val){
	for(var i in arr){
		if(arr[i] == val){
			return i;
		}
	}
}
//判定是否加载的函数
function checkScrollSlide(){
	//先取父元素
	var oParent = document.getElementById('main');
	var oBoxs = getByClass(oParent, 'box');
	//最后一个图片的高度
	var lastBoxH = oBoxs[oBoxs.length-1].offsetTop + Math.floor(oBoxs[oBoxs.length-1].offsetHeight/2);		//还要最后一个盒子高度的一半并取整
	//求页面滚动了多少像素
	var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
	//再加上可视区域的高度
	var height = document.body.clientHeight ||
	document.documentElement.clientHeight;

	//判断是否满足加载的条件
	return (lastBoxH < scrollTop + height) ? true : false;
}